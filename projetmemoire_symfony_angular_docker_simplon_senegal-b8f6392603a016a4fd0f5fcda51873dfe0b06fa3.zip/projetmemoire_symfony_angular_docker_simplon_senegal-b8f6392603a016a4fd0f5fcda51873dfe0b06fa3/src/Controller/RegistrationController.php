<?php

namespace App\Controller;

use App\Entity\Marraine;
use App\Entity\User;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Validator\Constraints as Assert;

use Symfony\Component\Validator\Validator\ValidatorInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;
use OpenApi\Annotations as OA;
 /**
 * @OA\Post(
 *     path="/api/inscrire-donateur",
 *     summary="Inscrire un nouveau donateur",
 *     description="Permet d'inscrire un nouveau donateur avec les informations fournies.",
 *     @OA\RequestBody(
 *         required=true,
 *         description="Données nécessaires pour l'inscription d'un donateur",
 *         @OA\JsonContent(
 *             required={"nom", "prenom", "email", "password", "adresse", "numeroTelephone"},
 *             @OA\Property(property="nom", type="string", example="Doe"),
 *             @OA\Property(property="prenom", type="string", example="John"),
 *             @OA\Property(property="email", type="string", format="email", example="johndoe@example.com"),
 *             @OA\Property(property="password", type="string", format="password", example="Password123"),
 *             @OA\Property(property="adresse", type="string", example="123 Rue Exemple"),
 *             @OA\Property(property="numeroTelephone", type="string", example="0123456789")
 *         )
 *     ),
 *     @OA\Response(
 *         response=201,
 *         description="Inscription du donateur réussie",
 *         @OA\JsonContent(
 *             type="object",
 *             @OA\Property(property="message", type="string", example="Inscription Donateur avec succès")
 *         )
 *     ),
 *     @OA\Response(
 *         response=400,
 *         description="Données invalides fournies"
 *     )
 * )
 */

#[Route('/api', name: 'api_')]
class RegistrationController extends AbstractController
{
    #[Route('/inscrire-donateur', name: 'inscrire_donateur', methods: ['POST'])]
   
    public function register(EntityManagerInterface $em, Request $request, UserPasswordHasherInterface $passwordHasher, ValidatorInterface $validator): JsonResponse
{
    $data = json_decode($request->getContent(), true);

    $constraints = new Assert\Collection([
        'nom' => [new Assert\NotBlank(), new Assert\Length(['min' => 4])],
        'prenom' => [new Assert\NotBlank(), new Assert\Length(['min' => 4])],
        'email' => [new Assert\NotBlank(), new Assert\Email()],
        'password' => [new Assert\NotBlank()],
        'adresse' => [new Assert\NotBlank()],
        'numeroTelephone' => [new Assert\NotBlank(), new Assert\Length(['min' => 5])],
    ]);

    $violations = $validator->validate($data, $constraints);
    if (count($violations) > 0) {
        return $this->json(['errors' => (string) $violations], JsonResponse::HTTP_BAD_REQUEST);
    }

    $user = new User();
    $user->setNom($data['nom']);
    $user->setPrenom($data['prenom']);
    $user->setEmail($data['email']);
    $user->setPassword($passwordHasher->hashPassword($user, $data['password']));
    $user->setAdresse($data['adresse']);
    $user->setNumeroTelephone($data['numeroTelephone']);
$user->setRoles(['ROLE_DONATEUR']);


    $em->persist($user);
    $em->flush();

    return $this->json(['message' => 'Inscription Donateur avec succès'], JsonResponse::HTTP_CREATED);
}
/**
 * @OA\Post(
 *     path="/api/devenir-marraine",
 *     summary="Inscrire un nouveau devenir-marraine",
 *     description="Permet d'inscrire un devenir-marraine",
 *     @OA\RequestBody(
 *         required=true,
 *         @OA\JsonContent(
 *             required={"nom", "prenom", "email", "password", "adresse", "numeroTelephone"},
 *             @OA\Property(property="nom", type="string", example="Dupont"),
 *             @OA\Property(property="prenom", type="string", example="Jean"),
 *             @OA\Property(property="email", type="string", format="email", example="jean.dupont@example.com"),
 *             @OA\Property(property="password", type="string", example="yourpassword"),
 *             @OA\Property(property="adresse", type="string", example="123 rue de la Paix"),
 *             @OA\Property(property="niveauEtude", type="string", example="Master en informatique"),
 *             @OA\Property(property="dateNaissance", type="string", format="date", example="1990-01-01")
 *         )
 *     ),
 *     @OA\Response(
 *         response=201,
 *         description="Marraine inscrit avec succès"
 *     ),
 *     @OA\Response(
 *         response=400,
 *         description="Données invalides"
 *     )
 * )
 */
#[Route('/devenir-marraine', name: 'devenir_marraine', methods: ['POST'])]
   
public function devenirMarraine(EntityManagerInterface $em, Request $request, UserPasswordHasherInterface $passwordHasher, ValidatorInterface $validator): JsonResponse
{
$data = json_decode($request->getContent(), true);

$constraints = new Assert\Collection([
    'nom' => [new Assert\NotBlank(), new Assert\Length(['min' => 4])],
    'prenom' => [new Assert\NotBlank(), new Assert\Length(['min' => 4])],
    'email' => [new Assert\NotBlank(), new Assert\Email()],
    'password' => [new Assert\NotBlank()],
    'adresse' => [new Assert\NotBlank()],
    'numeroTelephone' => [new Assert\NotBlank(), new Assert\Length(['min' => 5])],
]);

$violations = $validator->validate($data, $constraints);
if (count($violations) > 0) {
    return $this->json(['errors' => (string) $violations], JsonResponse::HTTP_BAD_REQUEST);
}

$user = new User();
$user->setNom($data['nom']);
$user->setPrenom($data['prenom']);
$user->setEmail($data['email']);
$user->setPassword($passwordHasher->hashPassword($user, $data['password']));
$user->setAdresse($data['adresse']);
$user->setNumeroTelephone($data['numeroTelephone']);
$user->setRoles(['ROLE_MARRAINE']);


$em->persist($user);
$em->flush();

return $this->json(['message' => 'Inscription Marraine|Parraine avec succès'], JsonResponse::HTTP_CREATED);
}

/**
 * @OA\Post(
 *     path="/api/inscrire-admin",
 *     summary="Inscrire un nouveau inscrire-admin",
 *     description="Permet d'inscrire un inscrire-admin",
 *     @OA\RequestBody(
 *         required=true,
 *         @OA\JsonContent(
 *             required={"nom", "prenom", "email", "password", "adresse", "numeroTelephone"},
 *             @OA\Property(property="nom", type="string", example="Dupont"),
 *             @OA\Property(property="prenom", type="string", example="Jean"),
 *             @OA\Property(property="email", type="string", format="email", example="jean.dupont@example.com"),
 *             @OA\Property(property="password", type="string", example="yourpassword"),
 *             @OA\Property(property="adresse", type="string", example="123 rue de la Paix"),
 *             @OA\Property(property="niveauEtude", type="string", example="Master en informatique"),
 *             @OA\Property(property="dateNaissance", type="string", format="date", example="1990-01-01")
 *         )
 *     ),
 *     @OA\Response(
 *         response=201,
 *         description="Admin inscrit avec succès"
 *     ),
 *     @OA\Response(
 *         response=400,
 *         description="Données invalides"
 *     )
 * )
 */

//ladmin
#[Route('/inscrire-admin', name: 'inscrire_admin', methods: ['POST'])]
public function ajouterUtilisateurAdmin(EntityManagerInterface $em, Request $request, UserPasswordHasherInterface $passwordHasher, ValidatorInterface $validator): JsonResponse
{
    $data = json_decode($request->getContent(), true);

    $constraints = new Assert\Collection([
        'nom' => [new Assert\NotBlank(), new Assert\Length(['min' => 2]), new Assert\Regex('/^[a-zA-Z]+$/')],
        'prenom' => [new Assert\NotBlank(), new Assert\Length(['min' => 4]), new Assert\Regex('/^[a-zA-Z]+$/')],
        'email' => [new Assert\NotBlank()],
        'password' => [new Assert\NotBlank()],
        'numeroTelephone' => [new Assert\NotBlank()],
     
    ]);

    $violations = $validator->validate($data, $constraints);
    if (count($violations) > 0) {
        return $this->json(['errors' => (string) $violations], JsonResponse::HTTP_BAD_REQUEST);
    }

   

    $user = new User();
    $user->setNom($data['nom']);
    $user->setPrenom($data['prenom']);
    $user->setEmail($data['email']);
    $user->setPassword($passwordHasher->hashPassword($user, $data['password']));
    $user->setNumeroTelephone($data['numeroTelephone']);
    $user->setRoles(['ROLE_ADMIN']); 

    

    $em->persist($user);
    $em->flush();

    return $this->json(['message' => 'Admin ajouté avec succès'], JsonResponse::HTTP_CREATED);
}



}
