<?php

namespace App\Controller;

use App\Entity\Newsletter;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Security;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

#[Route('/api', name: 'api_')]
class NewsletterController extends AbstractController
{
    private $security;

    public function __construct(Security $security)
    {
        $this->security = $security;
    }
    #[Route("/newsletter/souscription", name:"api_newsletter_souscription", methods:["POST"])]
    public function subscribe(Request $request, EntityManagerInterface $em): Response
    {
        $data = json_decode($request->getContent(), true);
    
        $newsletter = new Newsletter();
        $newsletter->setEmail($data['email']);
        $newsletter->setCreatedAt(new \DateTime());
    
        $user = $this->security->getUser();
        if ($user) {
            $newsletter->setUser($user);
        }
    
        $em->persist($newsletter);
        $em->flush();
    
        return new Response('Merci ! pour votre abonnement a notre Newsletter', Response::HTTP_CREATED);
    }
    
}
