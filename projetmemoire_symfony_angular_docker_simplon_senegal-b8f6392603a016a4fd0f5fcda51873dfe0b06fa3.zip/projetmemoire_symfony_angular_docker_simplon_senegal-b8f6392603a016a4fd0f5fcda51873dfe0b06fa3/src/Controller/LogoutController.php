<?php

namespace App\Controller;

use App\Service\TokenBlacklistService;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Security;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
#[Route('/api', name: 'api_')]
class LogoutController extends AbstractController
{
    private $tokenBlacklistService;

    public function __construct(TokenBlacklistService $tokenBlacklistService)
    {
        $this->tokenBlacklistService = $tokenBlacklistService;
    }

    #[Route('/logout', name: 'api_logout', methods: ['POST'])]
    public function logout(Request $request, Security $security): JsonResponse
    {
        $authorizationHeader = $request->headers->get('Authorization');
    
        if (!$authorizationHeader) {
            return new JsonResponse(['message' => 'Token non fourni'], JsonResponse::HTTP_BAD_REQUEST);
        }
    
        $token = str_replace('Bearer ', '', $authorizationHeader);
    
        // Ajouter le token à la liste noire
        $this->tokenBlacklistService->addToBlacklist($token);
    
        // Autres opérations de déconnexion (journalisation, etc.)
    
        return new JsonResponse(['message' => 'Déconnexion réussie']);
    }
    
}
