<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20240120141953 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        // $this->addSql('ALTER TABLE dahra ADD CONSTRAINT FK_487266D4A76ED395 FOREIGN KEY (user_id) REFERENCES user (id)');
        // $this->addSql('CREATE INDEX IDX_487266D4A76ED395 ON dahra (user_id)');
        $this->addSql('ALTER TABLE talibe ADD date_arrive_talibe DATE DEFAULT NULL, ADD presence_talibe VARCHAR(255) DEFAULT NULL');
        $this->addSql('ALTER TABLE user CHANGE email email VARCHAR(180) NOT NULL, CHANGE password password VARCHAR(255) NOT NULL');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE dahra DROP FOREIGN KEY FK_487266D4A76ED395');
        $this->addSql('DROP INDEX IDX_487266D4A76ED395 ON dahra');
        $this->addSql('ALTER TABLE talibe DROP date_arrive_talibe, DROP presence_talibe');
        $this->addSql('ALTER TABLE user CHANGE email email VARCHAR(180) DEFAULT NULL, CHANGE password password VARCHAR(255) DEFAULT NULL');
    }
}
